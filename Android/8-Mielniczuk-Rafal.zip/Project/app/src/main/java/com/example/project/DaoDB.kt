package com.example.project

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface DaoDB {
    @Query("SELECT * FROM item_table ORDER BY id ASC")
    fun getAllData(): MutableList<ItemDB>?
    @Query("DELETE FROM item_table")
    fun deleteAll()
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(item: ItemDB): Long
    @Delete()
    fun delete(item: ItemDB): Int
    @Update
    fun update(item: ItemDB)
    @Query("SELECT * FROM item_table WHERE id = :itemId")
    fun getItemById(itemId: Int): ItemDB?
    @Query("DELETE FROM item_table WHERE checked = :checkedValue")
    fun deleteChecked(checkedValue: Boolean)
}