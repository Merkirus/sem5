package com.example.project

import android.util.Log
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun ImageScreen() {
    ImageSlider(imageId = 0)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ImageSlider(imageId: Int) {

    val images = listOf(
        R.drawable.cat,
        R.drawable.dog,
        R.drawable.hamster
    )

    val pagerState = rememberPagerState(pageCount = {images.size}, initialPage = imageId)


    HorizontalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize(),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()) {
            Image(painter = painterResource(id = images[it]),
                contentDescription = null,
                modifier = Modifier.size(width = 200.dp, height = 200.dp),
                alignment = Alignment.Center)
            Spacer(modifier = Modifier.padding(16.dp))
            Button(onClick = {
                MainImage.image = images[it]
                Log.w("IMAGE_PRE", images[it].toString())
                Log.w("IMAGE", MainImage.image.toString())
            }) {
                Text(text = "Wybierz zdjęcie")
            }
        }
        
    }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
    }

}