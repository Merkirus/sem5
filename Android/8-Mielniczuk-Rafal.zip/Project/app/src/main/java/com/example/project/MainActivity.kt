package com.example.project

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.project.ui.theme.ProjectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProjectTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Setup()
                }
            }
        }
    }
}

@Composable
fun Setup() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = { NavDrawer(navController = navController, drawerState = drawerState, scope = scope) },
        content = {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = { Navigation(navController) },
                content = { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Home.route) {
                            HomeScreen()
                        }
                        composable(Screen.Image.route) {
                            ImageScreen()
                        }
                        composable(Screen.List.route) {
                            ListScreen(navController)
                        }
                        composable("details/{itemId}") {
                            val itemId = it.arguments?.getString("itemId")?.toIntOrNull() ?: null
                            DetailsScreen(navController, itemId)
                        }
                        composable("add/{itemId}") {
                            val itemId = it.arguments?.getString("itemId")?.toIntOrNull() ?: null
                            if (itemId == null) {
                                AddScreen(navController, itemId)
                            } else {
                                EditScreen(navController, itemId)
                            }
                        }
                    }
                }
            )
        }
    )
}