package com.example.project

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ItemDB::class], version = 1)
abstract class DatabaseDB: RoomDatabase() {
    abstract fun DaoDB(): DaoDB?

    companion object {
        private var DB_INSTANCE: DatabaseDB? = null
        @Synchronized
        open fun getDatabase(context: Context): DatabaseDB? {
            if (DB_INSTANCE == null) {
                DB_INSTANCE = Room.databaseBuilder(
                    context.applicationContext,
                    DatabaseDB::class.java,
                    "item_database"
                ).allowMainThreadQueries()
                    .build()
            }
            return DB_INSTANCE
        }
    }
}