package com.example.project

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ListViewModel(context: Context): ViewModel() {
    private val repo = RepositoryDB.getinstance(context)
    private val _items = MutableStateFlow<List<ItemDB>>(emptyList())
    val items: StateFlow<List<ItemDB>> = _items

    init {
        getData()
    }

    private fun getData() {
        viewModelScope.launch {
            _items.value = repo.getData() ?: emptyList()
        }
    }

    fun updateItem(item: ItemDB) {
        viewModelScope.launch {
            repo.updateItem(item)
            getData()
        }
    }

    fun deleteItem(item: ItemDB) {
        viewModelScope.launch {
            repo.deleteItem(item)
            getData()
        }
    }

    fun deleteCheckedItems() {
        viewModelScope.launch {
            repo.deleteCheckedItems()
            getData()
        }
    }
}