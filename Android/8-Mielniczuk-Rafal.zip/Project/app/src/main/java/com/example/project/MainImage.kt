package com.example.project

object MainImage {
    var image: Int = R.drawable.cat
}