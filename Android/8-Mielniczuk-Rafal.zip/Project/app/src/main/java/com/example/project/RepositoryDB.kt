package com.example.project

import android.content.Context

class RepositoryDB(context: Context) {
    private var dataList: MutableList<ItemDB>? = null
    private var dao: DaoDB
    private var db: DatabaseDB

    init {
        db = DatabaseDB.getDatabase(context)!!
        dao = db.DaoDB()!!

//        addItem(ItemDB())
//        addItem(ItemDB())
//        addItem(ItemDB())
//        addItem(ItemDB())
//        addItem(ItemDB())
//        addItem(ItemDB())
//        addItem(ItemDB())
//        addItem(ItemDB())
    }

    fun getData(): MutableList<ItemDB>? {
        dataList = dao.getAllData()
        return dataList
    }

    fun addItem(item: ItemDB): Boolean {
        if (dao.insert(item) >= 0) return true
        else return false
    }

    fun deleteItem(item: ItemDB): Boolean {
        if (dao.delete(item) > 0) return true
        else return false
    }

    fun deleteCheckedItems() {
        dao.deleteChecked(true)
    }

    fun deleteAll(): Boolean {
        dao.deleteAll()
        return true
    }

    fun getItemById(itemId: Int): ItemDB? {
        return try {
            dao.getItemById(itemId)
        } catch (e: Exception) {
            null
        }
    }

    fun updateItem(item: ItemDB) {
        dao.update(item)
    }

    companion object {
        private var R_INSTANCE: RepositoryDB? = null

        fun getinstance(context: Context): RepositoryDB {
            if (R_INSTANCE == null) {
                R_INSTANCE = RepositoryDB(context)
            }
            return R_INSTANCE as RepositoryDB
        }
    }
}