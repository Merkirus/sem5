package com.example.project

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home: Screen("home", "Home", Icons.Default.Home)
    object Image: Screen("image", "Image", Icons.Default.AccountCircle)
    object List: Screen("list", "List", Icons.Default.List)
}