package com.example.project

import android.annotation.SuppressLint
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(navController: NavController) {
    val context = LocalContext.current

    val listViewModel = remember { ListViewModel(context) }
    val items by listViewModel.items.collectAsState()

    @Composable
    fun ListItem(item: ItemDB, onClick: () -> Unit) {
        val showDialog = remember { mutableStateOf(false) }
        val green = Color.Green.copy(alpha = 0.3f)
        val red = Color.Red.copy(alpha = 0.5f)
        val yellow = Color.Yellow.copy(alpha = 0.5f)
        val color = when (item.power) {
            "weak" -> green
            "medium" -> yellow
            "strong" -> red
            else -> yellow
        }
        Row (
            modifier = Modifier
                .combinedClickable(onClick = onClick, onLongClick = { showDialog.value = true })
                .fillMaxWidth()
                .background(color),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(painterResource(id =
                when (item.category) {
                    "cat" -> R.drawable.cat
                    "dog" -> R.drawable.dog
                    "hamster" -> R.drawable.hamster
                    else -> R.drawable.cat
                }), contentDescription = null, modifier = Modifier.size(100.dp, 100.dp))
            Column {
                Text(text = item.name.toString(),
                    style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp))
                Text(text = item.species.toString(),
                    style = MaterialTheme.typography.labelSmall)
            }
            Spacer(modifier = Modifier.weight(3F))
            Checkbox(checked = item.checked, onCheckedChange = {
                item.checked = it
                listViewModel.updateItem(item) })

        }

        if (showDialog.value) {
            DeleteDialog(onConfirm = {
                listViewModel.deleteItem(item)
                showDialog.value = false
            }, onDismiss = {
                showDialog.value = false
            })
        }
    }

    Scaffold(
        topBar = { TopAppBar(
            title = { Text("Baza danych") },
            actions = {
                IconButton(onClick = {
                    listViewModel.deleteCheckedItems()
                }) {
                    Icon(imageVector = Icons.Default.Clear, contentDescription = null)
                }
            })},
        floatingActionButton = {
            ExtendedFloatingActionButton(
                icon = { Icon(imageVector = Icons.Default.Add, contentDescription = null) },
                text = { Text("Add") },
                onClick = { navController.navigate("add/null") },
                modifier = Modifier.padding(16.dp)
            )
        },
    ) {
        LazyColumn(modifier = Modifier.padding(it)) {
            items(items) { item ->
                ListItem(item,
                    onClick = { navController.navigate("details/${item.id}") }
                )
            }
        }
    }
}

@Composable
fun DeleteDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Confirm Delete") },
        text = { Text("Are you sure you want to delete this item?") },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Yes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("No")
            }
        }
    )
}