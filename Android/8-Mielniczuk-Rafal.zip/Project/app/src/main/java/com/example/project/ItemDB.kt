package com.example.project

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.GregorianCalendar
import java.util.Locale
import kotlin.random.Random

@Entity(tableName = "item_table")
class ItemDB {
    @PrimaryKey(autoGenerate = true)
    var id = 0

    @ColumnInfo(name = "name")
    var name: String? = null

    @ColumnInfo(name = "species")
    var species: String? = null

    @ColumnInfo(name = "rating")
    var rating = 0

    @ColumnInfo(name = "age")
    var age: String? = null

    @ColumnInfo(name = "power")
    var power: String? = null

    @ColumnInfo(name = "category")
    var category: String? = null

    @ColumnInfo(name = "checked")
    var checked: Boolean = false

    constructor() {
        category = CATEGORIES.random()
        name = NAMES.random()
        when (category) {
            "cat" -> species = CAT_SPECIES.random()
            "dog" -> species = DOG_SPIECIES.random()
            "hamster" -> species = HAMSTER_SPECIES.random()
        }
        when (category) {
            "hamster" -> power = "weak"
            "cat" -> power = "medium"
            "dog" -> power = "strong"
        }
        val year = Random.nextInt(1990, 2023)
        val month = Random.nextInt(0, 12)
        val day = Random.nextInt(1, 28)
        rating = Random.nextInt(0,101)
        age = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(GregorianCalendar(year, month, day).time)
    }

    constructor(name: String?, species: String?, rating: Int?, age: String?, category: String?, power: String?) {
        this.name = name ?: DEFAULT_NAME
        this.species = species ?: DEFAULT_SPECIES
        this.rating = rating ?: DEFAULT_RATING
        this.age = age ?: DEFAULT_AGE
        this.category = category ?: DEFAULT_CATEGORY
        this.power = power ?: DEFAULT_POWER
    }

    companion object {
        val DEFAULT_POWER = "medium"
        val DEFAULT_NAME = "Coco"
        val DEFAULT_SPECIES = "Syrian Hamster"
        val DEFAULT_RATING = 100
        val DEFAULT_AGE = "13-04-2012"
        val DEFAULT_CATEGORY = "hamster"
        val CATEGORIES = arrayOf("cat", "dog", "hamster")
        val NAMES = arrayOf("Pimpek", "Coco", "Bobo", "Puszek", "Arnold", "Pipi", "Kajtek", "Fifi")
        val HAMSTER_SPECIES = arrayOf("Chinese Hamster", "Syrian Hamster", "Campbells Hamster")
        val DOG_SPIECIES = arrayOf("Husky", "Dachshund", "Pomeranian")
        val CAT_SPECIES = arrayOf("British cat", "Scottish cat", "Russian Cat", "Persian Cat")
    }
}