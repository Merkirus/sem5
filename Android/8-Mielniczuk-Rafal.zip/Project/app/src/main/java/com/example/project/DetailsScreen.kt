package com.example.project

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun DetailsScreen(navController: NavController, itemId: Int?) {
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var species by remember { mutableStateOf("") }
    var rating by remember { mutableIntStateOf(0) }
    var age by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var power by remember { mutableStateOf("") }

    if (itemId != null) {
        val item = RepositoryDB.getinstance(context).getItemById(itemId)
        name = item?.name ?: ""
        species = item?.species ?: ""
        rating = item?.rating ?: 0
        age = item?.age ?: ""
        category = item?.category ?: ""
        power = item?.power ?: ""
    }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TextField(
            value = name,
            onValueChange = {name = it},
            label = { Text("Imię") },
            modifier = Modifier.padding(16.dp),
            readOnly = true)

        TextField(
            value = species,
            onValueChange = {species = it},
            label = { Text("Gatunek") },
            modifier = Modifier.padding(16.dp),
            readOnly = true)

        RadioGroup2(
            items = listOf("cat", "dog", "hamster"),
            selected = category,
            onOptionSelected = {category = it
            Log.w("INSIDE RADIO", category)}
        )

        Slider(
            value = rating.toFloat(),
            onValueChange = { rating = it.toInt() },
            valueRange = 0f..100f,
            modifier = Modifier.width(250.dp))

        Spinner2(
            items = listOf("weak", "medium", "strong"),
            preselected = power, onOptionSelected = {power = it})

        TextField(
            value = age,
            onValueChange = {age = it},
            label = { Text("Data ur.") },
            modifier = Modifier.padding(16.dp),
            placeholder = { Text("DD-MM-YYYY") },
            readOnly = true)


        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Button(
                onClick = {
                    Log.w("ITEM", "$name, $species, $rating, $age, $category, $power")
                    val item = ItemDB(
                        name,
                        species,
                        rating,
                        age,
                        category,
                        power
                    )
                    navController.navigate("add/$itemId")
                },
                modifier = Modifier.padding(end = 16.dp)
            ) {
                Text("Edit")
            }

            Button(
                onClick = {
                    navController.popBackStack()
                }
            ) {
                Text("Back")
            }
        }
    }
}

@Composable
fun Spinner2(items: List<String>,
            preselected: String,
            onOptionSelected: (String) -> Unit) {

    Box {
        Column {
            OutlinedTextField(
                value = preselected,
                onValueChange = { onOptionSelected(it) },
                readOnly = true,
                trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, null) } )

            DropdownMenu(expanded = false,
                onDismissRequest = { }) {


                items.forEach {
                    DropdownMenuItem(text = { Text(it) },
                        onClick = { })
                }


            }
        }
    }




}

@Composable
fun RadioGroup2(items: List<String>,
               selected: String,
               onOptionSelected: (String) -> Unit) {

    Column {
        items.forEach {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .selectable(
                        selected = (it == selected),
                        onClick = {  }
                    )
                    .background(Color.Transparent)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                RadioButton(
                    selected = (it == selected),
                    onClick = {  },
                    modifier = Modifier
                        .size(24.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(text = it)
            }
        }
    }
}