package com.example.ex2

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipData.Item
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.AdapterContextMenuInfo
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.view.menu.MenuBuilder

class MainActivity : AppCompatActivity() {

    val contextMenuItems1 = mutableListOf(false, false, false)
    val contextMenuItems2 = mutableListOf(false, false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyTheme()
        setContentView(R.layout.activity_main)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        val button1: Button = findViewById(R.id.button1)
        val button2: Button = findViewById(R.id.button2)
        val button3: Button = findViewById(R.id.button3)

        registerForContextMenu(button1)
        registerForContextMenu(button2)

        button1.setOnClickListener {
            setPrefs(1)
            recreate()
        }
        button2.setOnClickListener {
            setPrefs(2)
            recreate()
        }
        button3.setOnClickListener {
            setPrefs(3)
            recreate()
        }

        val rightButton: Button = findViewById(R.id.button_right)
        val leftButton: Button = findViewById(R.id.button_left)

        rightButton.setOnClickListener {
            val iii = Intent(this, ActivityRight::class.java)
            startActivity(iii)
        }
    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        if (menu is MenuBuilder)
            menu.setOptionalIconsVisible(true)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.menu_themeEx -> {
                setPrefs(0)
                recreate()
                true
            }
            R.id.menu_theme1 -> {
                setPrefs(1)
                recreate()
                true
            }
            R.id.menu_theme2 -> {
                setPrefs(2)
                recreate()
                true
            }
            R.id.menu_theme3 -> {
                setPrefs(3)
                recreate()
                true
            }
            R.id.menu_reset -> {
                setPrefs(4)
                recreate()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        when (v?.id) {
            R.id.button1 -> menuInflater.inflate(R.menu.context_menu1, menu)
            R.id.button2 -> menuInflater.inflate(R.menu.context_menu2, menu)
        }

        if (contextMenuItems1.contains(true)) {
            var index = 0
            contextMenuItems1.forEachIndexed() { i, value ->
                if (value) {
                    index = i
                }
            }
            when (index) {
                0 -> menu?.findItem(R.id.menu_20)?.isChecked = true
                1 -> menu?.findItem(R.id.menu_22)?.isChecked = true
                2 -> menu?.findItem(R.id.menu_24)?.isChecked = true
            }
        }

        if (contextMenuItems2.contains(true)) {
            var index = 0
            contextMenuItems2.forEachIndexed() { i, value ->
                if (value) {
                    index = i
                }
            }
            when (index) {
                0 -> menu?.findItem(R.id.menu_bold)?.isChecked = true
                1 -> menu?.findItem(R.id.menu_italic)?.isChecked = true
            }
        }

//        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.menu_20 -> {
                contextMenuItems1[0] = !contextMenuItems1[0]
                item.isChecked = contextMenuItems1[0]
                findViewById<Button>(R.id.button1).setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                true
            }
            R.id.menu_22 -> {
                contextMenuItems1[1] = !contextMenuItems1[1]
                item.isChecked = contextMenuItems1[1]
                findViewById<Button>(R.id.button1).setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                true
            }
            R.id.menu_24 -> {
                contextMenuItems1[2] = !contextMenuItems1[2]
                item.isChecked = contextMenuItems1[2]
//                theme.applyStyle(R.style.MyTextView, true)
//                setPrefs(9)
//                recreate()
//                findViewById<Button>(R.id.button1).setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                true
            }
            R.id.menu_bold -> {
                contextMenuItems2[0] = !contextMenuItems2[0]
                item.isChecked = contextMenuItems2[0]
                findViewById<Button>(R.id.button2).setTypeface(null, Typeface.BOLD)
                true
            }

            R.id.menu_italic -> {
                contextMenuItems2[1] = !contextMenuItems2[1]
                item.isChecked = contextMenuItems2[1]
                findViewById<Button>(R.id.button2).setTypeface(null, Typeface.ITALIC)
                true
            }
            else -> return super.onContextItemSelected(item)
        }
    }

    private fun setPrefs(themeNum: Int) {
        val data: SharedPreferences = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)

        val editor = data.edit()
        editor.putInt("theme_num", themeNum)
        editor.apply()
    }

    private fun applyTheme() {
        val data = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        when (data.getInt("theme_num", 0)) {
            1 -> setTheme(R.style.AppTheme1)
            2 -> setTheme(R.style.AppTheme2)
            3 -> setTheme(R.style.AppTheme3)
            9 -> setTheme(R.style.MyTheme)
            else -> setTheme(R.style.Theme_Ex2)
        }
    }
}