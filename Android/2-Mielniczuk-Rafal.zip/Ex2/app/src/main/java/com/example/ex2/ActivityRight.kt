package com.example.ex2

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class ActivityRight : AppCompatActivity() {

    private var myAM: ActionMode? = null

    private var dialogOptions = arrayOf("Car", "Bus", "Train")
    private var checkedItems = BooleanArray(3)

    private var chosenItem = ""

    val myAMCallback: ActionMode.Callback = object: ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            menuInflater.inflate(R.menu.context_action, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {return true}

        override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
            when (item?.itemId) {
                R.id.menu_pink -> {
                    findViewById<TextView>(R.id.right_text2).setTextColor(resources.getColor(R.color.pink))
                }
                R.id.menu_blue -> {
                    findViewById<TextView>(R.id.right_text2).setTextColor(resources.getColor(R.color.blue))
                }
                R.id.menu_yellow -> {
                    findViewById<TextView>(R.id.right_text2).setTextColor(resources.getColor(R.color.yellow))
                }
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode?) {
            myAM = null
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_right)
        
        val textColor: TextView = findViewById(R.id.right_text2)
        textColor.setOnLongClickListener {

            if (myAM != null)
                return@setOnLongClickListener false

            myAM = startActionMode(myAMCallback)

            true
        }

        val textBirth: TextView = findViewById(R.id.right_text4)
        textBirth.setOnClickListener {
            val cal = Calendar.getInstance()
            val dateDialog = DatePickerDialog(this, {view, year, monthOfYear, dayOfMonth ->
                textBirth.text = (dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
            },
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
            dateDialog.show()
        }

        val backButton: Button = findViewById(R.id.back_button)

        backButton.setOnClickListener {
            val builder: AlertDialog.Builder = AlertDialog.Builder(this)
            builder
                .setTitle("Go back dialog")
//                .setMessage("Are you sure at 100% ?")
                .setPositiveButton("Accept") { dialog, which ->
                    Toast.makeText(applicationContext, chosenItem, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel") { dialog, which ->
                    dialog.cancel()
                }
                .setMultiChoiceItems(dialogOptions, checkedItems, object: DialogInterface.OnMultiChoiceClickListener {
                    override fun onClick(dialog: DialogInterface?, which: Int, isChecked: Boolean) {
                        if (isChecked)
                            chosenItem += dialogOptions.get(which) + " "

                    }

                })
            builder.create().show()
        }
    }
}