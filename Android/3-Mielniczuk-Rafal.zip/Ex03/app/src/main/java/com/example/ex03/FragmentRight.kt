package com.example.ex03

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.ActionMode
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentRight.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentRight : Fragment() {

    private var myAM: ActionMode? = null

    private var dialogOptions = arrayOf("Car", "Bus", "Train")
    private var checkedItems = BooleanArray(3)

    private var chosenItem = ""

    val myAMCallback: ActionMode.Callback = object: ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            activity?.menuInflater?.inflate(R.menu.context_menu, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {return true}

        override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
            when (item?.itemId) {
                R.id.menu_pink -> {
                    requireView().findViewById<TextView>(R.id.right_text2).setTextColor(resources.getColor(R.color.pink))
                }
                R.id.menu_blue -> {
                    requireView().findViewById<TextView>(R.id.right_text2).setTextColor(resources.getColor(R.color.blue))
                }
                R.id.menu_yellow -> {
                    requireView().findViewById<TextView>(R.id.right_text2).setTextColor(resources.getColor(R.color.yellow))
                }
            }
            myAM?.finish()
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode?) {
            myAM = null
        }

    }


    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_right, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val textColor: TextView = requireView().findViewById(R.id.right_text2)
        textColor.setOnLongClickListener {

            if (myAM != null)
                return@setOnLongClickListener false

            myAM = requireView().startActionMode(myAMCallback)

            true
        }

        val textBirth: TextView = requireView().findViewById(R.id.right_text4)
        textBirth.setOnClickListener {
            val cal = Calendar.getInstance()
            val dateDialog = DatePickerDialog(requireContext(), {view, year, monthOfYear, dayOfMonth ->
                textBirth.text = (dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
            },
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
            dateDialog.show()
        }

        val backButton: Button = requireView().findViewById(R.id.back_button)

        backButton.setOnClickListener {
            val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
            builder
                .setTitle("Go back dialog")
//                .setMessage("Are you sure at 100% ?")
                .setPositiveButton("Accept") { dialog, which ->
                    Toast.makeText(requireContext(), chosenItem, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel") { dialog, which ->
                    dialog.cancel()
                }
                .setMultiChoiceItems(dialogOptions, checkedItems, object: DialogInterface.OnMultiChoiceClickListener {
                    override fun onClick(dialog: DialogInterface?, which: Int, isChecked: Boolean) {
                        if (isChecked)
                            chosenItem += dialogOptions.get(which) + " "

                    }

                })
            builder.create().show()
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentRight.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentRight().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
