package com.example.ex03

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.fragment.NavHostFragment
import com.example.ex03.ui.theme.Ex03Theme
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView

class MainActivity : AppCompatActivity() { //, StaticFragment.OnSelectListener {


//    private val TAG_F1 = "Fragment1"
//    private val TAG_F2 = "Fragment2"
//
//    var frag1: Fragment1? = null
//    var frag2: Fragment2? = null
//    var myTrans: FragmentTransaction? = null
    var navBarState = mutableListOf<Int>(0)
    var bottomNavigationView: BottomNavigationView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment
        val navController = navHostFragment.navController
        bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavView)
        bottomNavigationView?.menu?.findItem(R.id.center_frag)?.isChecked = true

        bottomNavigationView?.setOnItemSelectedListener (object: NavigationBarView.OnItemSelectedListener {
            override fun onNavigationItemSelected(item: MenuItem): Boolean {
                when (item.itemId) {
                    R.id.left_frag -> {
                        navController.navigate(R.id.action_global_to_fragLeft)
                        navBarState.add(2)
                    }
                    R.id.center_frag -> {
                        navController.navigate(R.id.action_global_to_fragCenter)
                        navBarState.add(0)
                    }
                    R.id.right_frag -> {
                        navController.navigate(R.id.action_global_to_fragRight)
                        navBarState.add(1)
                    }
                }
//                updateNavBar(bottomNavigationView)
                return true
            }
        })

//        if (savedInstanceState == null) {
//            Log.w("XD", "ZLE")
//            frag1 = Fragment1.newInstance("","")
//            frag2 = Fragment2.newInstance("","")
//
//            myTrans = supportFragmentManager.beginTransaction()
//            myTrans!!.add(R.id.dynamicFragmentView, frag1!!, TAG_F1)
//            myTrans!!.detach(frag1!!)
//            myTrans!!.add(R.id.dynamicFragmentView, frag2!!, TAG_F2)
//            myTrans!!.detach(frag2!!)
//            myTrans!!.commit()
//        } else {
//            Log.w("XD", "DOBRZE")
//            frag1 = supportFragmentManager.findFragmentByTag(this.TAG_F1) as Fragment1?
//            frag2 = supportFragmentManager.findFragmentByTag(this.TAG_F2) as Fragment2?
//        }
    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
//        if (menu is MenuBuilder)
//            menu.setOptionalIconsVisible(true)
//        true
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_theme1 -> {true}
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
//        navBarState.removeAt(navBarState.size-1)
//        updateNavBar()
        super.onBackPressed()
    }

    private fun updateNavBar() {
        when (navBarState.get(navBarState.size-1)) {
            0 -> bottomNavigationView?.menu?.findItem(R.id.center_frag)?.isChecked = true
            1 -> bottomNavigationView?.menu?.findItem(R.id.right_frag)?.isChecked = true
            2 -> bottomNavigationView?.menu?.findItem(R.id.left_frag)?.isChecked = true
        }
    }

//    override fun onSelect(option: Int) {
//        myTrans = supportFragmentManager.beginTransaction()
//        when (option) {
//            1 -> {
//                myTrans!!.detach(frag2!!)
//                myTrans!!.attach(frag1!!)
//            }
//            2 -> {
//                myTrans!!.detach(frag1!!)
//                myTrans!!.attach(frag2!!)
//            }
//        }
//        myTrans!!.commit()
//    }

}
