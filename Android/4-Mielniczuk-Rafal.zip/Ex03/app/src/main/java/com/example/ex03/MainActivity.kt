package com.example.ex03

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.text.BoringLayout
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toolbar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.os.bundleOf
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.setFragmentResult
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.ex03.ui.theme.Ex03Theme
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.navigation.NavigationView
import java.text.SimpleDateFormat
import java.util.GregorianCalendar
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() { //, StaticFragment.OnSelectListener {


//    private val TAG_F1 = "Fragment1"
//    private val TAG_F2 = "Fragment2"
//
//    var frag1: Fragment1? = null
//    var frag2: Fragment2? = null
//    var myTrans: FragmentTransaction? = null
    var navBarState = mutableListOf<Int>(0)
    var bottomNavigationView: BottomNavigationView? = null
    var menuMain: Menu? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout = findViewById(R.id.drawerLayout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val navController: NavController = (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).navController

        val appBarConfiguration = AppBarConfiguration(setOf(R.id.center_frag, R.id.left_frag, R.id.right_frag, R.id.extra_frag), drawerLayout)

        toolbar.setupWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

//        val navHostFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment
//        val navController = navHostFragment.navController
//        bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavView)
//        bottomNavigationView?.menu?.findItem(R.id.center_frag)?.isChecked = true
//
//        bottomNavigationView?.setOnItemSelectedListener (object: NavigationBarView.OnItemSelectedListener {
//            override fun onNavigationItemSelected(item: MenuItem): Boolean {
//                when (item.itemId) {
//                    R.id.left_frag -> {
//                        navController.navigate(R.id.action_global_to_fragLeft)
//                        navBarState.add(2)
//                    }
//                    R.id.center_frag -> {
//                        navController.navigate(R.id.action_global_to_fragCenter)
//                        navBarState.add(0)
//                    }
//                    R.id.right_frag -> {
//                        navController.navigate(R.id.action_global_to_fragRight)
//                        navBarState.add(1)
//                    }
//                }
////                updateNavBar(bottomNavigationView)
//                return true
//            }
//        })
    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuMain = menu
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_delete -> {
                (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).childFragmentManager.setFragmentResult("delete", bundleOf("delete" to true))
                true
            }
            else -> false
        }
    }

    fun setupToolbarFragRight() {
        menuInflater.inflate(R.menu.delete_menu, menuMain)
    }

    fun clearMenu() {
        menuMain?.clear()
    }

//    @SuppressLint("RestrictedApi")
//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.menu, menu)
////        if (menu is MenuBuilder)
////            menu.setOptionalIconsVisible(true)
////        true
//        return super.onCreateOptionsMenu(menu)
//    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        return when (item.itemId) {
//            R.id.menu_theme1 -> {true}
//            else -> super.onOptionsItemSelected(item)
//        }
//    }

//    private fun updateNavBar() {
//        when (navBarState.get(navBarState.size-1)) {
//            0 -> bottomNavigationView?.menu?.findItem(R.id.center_frag)?.isChecked = true
//            1 -> bottomNavigationView?.menu?.findItem(R.id.right_frag)?.isChecked = true
//            2 -> bottomNavigationView?.menu?.findItem(R.id.left_frag)?.isChecked = true
//        }
//    }

}

class DataItem {
    val CATEGORIES = arrayOf("cat", "dog", "hamster")
    val NAMES = arrayOf("Pimpek", "Coco", "Bobo", "Puszek", "Arnold", "Pipi", "Kajtek", "Fifi")
    val HAMSTER_SPECIES = arrayOf("Chinese Hamster", "Syrian Hamster", "Campbells Hamster")
    val DOG_SPIECIES = arrayOf("Husky", "Dachshund", "Pomeranian")
    val CAT_SPECIES = arrayOf("British cat", "Scottish cat", "Russian Cat", "Persian Cat")

    var text_main : String = NAMES.random() // name
    var text_2 : String = "" // species
    var item_value : Int = Random.nextInt(0, 101) // cuteness
    var item_value2: String = "" // birth
    var item_type : String = CATEGORIES.random()
    var item_checked : Boolean = false
    constructor()
    constructor(num: Int) : this() {
        when (item_type) {
            "cat" -> text_2 = CAT_SPECIES.random()
            "dog" -> text_2 = DOG_SPIECIES.random()
            "hamster" -> text_2 = HAMSTER_SPECIES.random()
        }
        val year = Random.nextInt(1990, 2023)
        val month = Random.nextInt(0,12)
        val day = Random.nextInt(1, 28)
        item_value2 = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(GregorianCalendar(year, month, day).time)
    }
    constructor(num: Int, name: String, species: String, cuteness: Int, birth: String, category: String) : this() {
        item_type = category
        text_main = name
        item_value2 = birth
        item_value = cuteness
        text_2 = species
    }

    companion object {
        val DEFAULT_TEXT_MAIN = "Coco"
        val DEFAULT_TEXT2 = "Syrian Hamster"
        val DEFAULT_ITEM_VALUE = 100
        val DEFAULT_ITEM_VALUE2 = "13-04-2012"
        val DEFAULT_ITEM_TYPE = "hamster"
    }
}

class DataRepo
{
    var LIST_SIZE = 10
    val item_text_list = Array(LIST_SIZE) { i -> "Item name " +i}
    private lateinit var dataList: MutableList<DataItem>
    companion object{
        private var INSTANCE: DataRepo? = null
        fun getinstance(): DataRepo {
            if (INSTANCE == null){
                INSTANCE = DataRepo()
            }
            return INSTANCE as DataRepo
        }
    }
    fun getData() : MutableList<DataItem> {
        return dataList
    }
    init {
        dataList = MutableList(LIST_SIZE) { i -> DataItem(i)}
    }
    fun addItem() {
        val num = LIST_SIZE
        dataList.add(DataItem(num))
        LIST_SIZE += 1
    }
    fun addItem(name: String?, species: String?, cuteness: Int?, birth: String?, category: String?) {
        val num = LIST_SIZE
        dataList.add(DataItem(num, name ?: DataItem.DEFAULT_TEXT_MAIN,
            species ?: DataItem.DEFAULT_TEXT2,
            cuteness ?: DataItem.DEFAULT_ITEM_VALUE,
            birth ?: DataItem.DEFAULT_ITEM_VALUE2,
            category ?: DataItem.DEFAULT_ITEM_TYPE))
        LIST_SIZE += 1
    }
    fun deleteItem(index: Int): Boolean {
        val oldListSize = LIST_SIZE
        dataList.removeAt(index)
        LIST_SIZE = dataList.size
        return LIST_SIZE != oldListSize
    }
    fun deleteItems(): Boolean {

        dataList.removeIf { it.item_checked }

        LIST_SIZE = dataList.size
        return true
    }
    fun updateItem(index: Int, name: String, species: String, cuteness: Int, birth: String, category: String) {
        dataList[index].text_main = name
        dataList[index].text_2 = species
        dataList[index].item_value = cuteness
        dataList[index].item_value2 = birth
        dataList[index].item_type = category
    }
    fun checkItem(index: Int, check: Boolean) {
        dataList[index].item_checked = check
    }
}