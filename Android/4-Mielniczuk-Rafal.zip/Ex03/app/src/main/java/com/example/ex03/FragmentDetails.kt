package com.example.ex03

import android .os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentDetails.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentDetails : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    var position: String? = null
    var params: Bundle? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        parentFragmentManager.setFragmentResultListener("detailsItem", viewLifecycleOwner) {
                requestKey, bundle -> params = bundle; fillView(view)
        }

        fillView(view)

        val backButton: Button = view.findViewById(R.id.details_back_button)
        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        val editButton: Button = view.findViewById(R.id.details_edit_button)
        editButton.setOnClickListener {
            parentFragmentManager.setFragmentResult("editItem", params!!)
            findNavController().navigate(R.id.action_local_to_fragEdit)
        }
    }

    private fun fillView(view: View) {
        view.findViewById<TextView>(R.id.details_name).text = params?.getString("name")
        view.findViewById<TextView>(R.id.details_species).text = params?.getString("species")
        when (params?.getString("category")) {
            "cat" -> view.findViewById<ImageView>(R.id.details_image).setImageResource(R.drawable.cat)
            "dog" -> view.findViewById<ImageView>(R.id.details_image).setImageResource(R.drawable.dog)
            "hamster" -> view.findViewById<ImageView>(R.id.details_image).setImageResource(R.drawable.hamster)
        }
        view.findViewById<SeekBar>(R.id.details_cuteness).progress =
            params?.getString("cuteness")?.toInt() ?: 0
        view.findViewById<TextView>(R.id.details_birth).text = params?.getString("birth")
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentDetails.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentDetails().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}