package com.example.ex03

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toolbar
import androidx.appcompat.view.menu.MenuBuilder
import androidx.core.os.bundleOf
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.commit
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentExtra.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentExtra : Fragment() {

    private var param1: String? = null
    private var param2: String? = null

    lateinit var value: String

    var info: String? = null
    var inv: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
//        if (savedInstanceState == null) {
////            frag1 = Fragment1.newInstance("f1", "Page #1")
////            frag2 = Fragment2.newInstance("f2","Page #2")
////            myTrans = childFragmentManager.beginTransaction()
////            myTrans!!.add(frag1!!, TAG_F1)
////            myTrans!!.detach(frag1!!)
////            myTrans!!.add(frag2!!, TAG_F2)
////            myTrans!!.detach(frag2!!)
////            myTrans!!.commit()
//        }
        Log.w("XD", "GIT")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_extra, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val vpAdapter = MyPagerAdapter2(this)
        val vPager = view.findViewById(R.id.vp2) as ViewPager2
        vPager.adapter = vpAdapter

        val tabLayout = view.findViewById(R.id.tabLayout) as TabLayout

        val tabIcons = arrayOf(R.drawable.ic_img1, R.drawable.ic_img2)

        val tabLM = TabLayoutMediator(tabLayout, vPager, object: TabLayoutMediator.TabConfigurationStrategy {
            override fun onConfigureTab(tab: TabLayout.Tab, position: Int) {
                tab.text = "Tab ${(position + 1)}"
                tab.setIcon(tabIcons[position])
            }
        })

        tabLM.attach()

        Log.w("EXTRA", childFragmentManager.fragments.toString())
        childFragmentManager.setFragmentResultListener("tab2Results", viewLifecycleOwner) {
            requestKey, bundle ->
            info = bundle.getString("info")
            inv = bundle.getString("inv")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (inv == null)
            inv = getString(R.string.invitation)
        if (info == null)
            info = getString(R.string.author_info)
        val bundle = bundleOf("invitation" to inv, "info" to info)
        parentFragmentManager.setFragmentResult("setupMain", bundle)
        Log.w("EXTRA", "CHANGE FRAGMENT")
        Log.w("EXTRA", inv?:"NOTHING")
    }

//    override fun onDestroy() {
//        super.onDestroy()
//        parentFragmentManager.setFragmentResult("extraMessage", bundleOf("result" to value))
//    }

//    @SuppressLint("RestrictedApi")
//    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
//        super.onCreateOptionsMenu(menu, inflater)
//        activity?.menuInflater?.inflate(R.menu.menu, menu)
//        if (menu is MenuBuilder)
//            menu.setOptionalIconsVisible(true)
//        true
////        return super.onCreateOptionsMenu(menu)
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        return when (item.itemId) {
//            R.id.extra_menu_button -> {view?.findViewById<EditText>(R.id.extraEditText)?.setText("Mielniczuk")
//            true}
//            else -> true
//        }
//    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentExtra.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentExtra().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    inner class MyPagerAdapter2(frag: Fragment): FragmentStateAdapter(frag) {

        private val TAG_F1 = "Fragment1"
        private val TAG_F2 = "Fragment2"

        var frag1: Fragment1? = null
        var frag2: Fragment2? = null
        var myTrans: FragmentTransaction? = null

        val PAGE_COUNT = 2

        override fun getItemCount(): Int {
            return PAGE_COUNT
        }

        override fun createFragment(position: Int): Fragment {
            if (position == 0)
                return Fragment1.newInstance("","")
            else
                return Fragment2.newInstance("","")
        }

    }
}

