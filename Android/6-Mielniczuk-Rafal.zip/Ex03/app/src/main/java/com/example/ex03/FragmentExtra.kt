package com.example.ex03

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.io.FileNotFoundException
import java.io.InputStream

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentExtra.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentExtra : Fragment() {

    private var param1: String? = null
    private var param2: String? = null

    lateinit var value: String

    var info: String? = null
    var inv: String? = null

    lateinit var adapter: MyAdapterImage

    private val Diffcallback = object: DiffUtil.ItemCallback<ImageItem>() {
        override fun areItemsTheSame(oldItem: ImageItem, newItem: ImageItem): Boolean {
            return oldItem.name == newItem.name
        }

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: ImageItem, newItem: ImageItem): Boolean {
            return oldItem == newItem
        }
    }

    val onItemAction: (item: ImageItem, action: Int) -> Unit = {
        item, action ->
        val data = ImageDataRepo.getinstance(requireContext())
        when (action) {
            1 -> {
                findNavController().navigate(R.id.action_local_to_fragEdit)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
        Log.w("XD", "GIT")
        adapter = MyAdapterImage(onItemAction)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_extra, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as MainActivity).setupToolbarFragExtra()

        val dataRepo: ImageDataRepo = ImageDataRepo.getinstance(requireContext())


        Log.w("EXTRA SHARED", dataRepo.getSharedList()?.size.toString())
        Log.w("EXTRA PRIVATE", dataRepo.getAppList()?.size.toString())

        val recView = view.findViewById<RecyclerView>(R.id.recycleViewImage)
        recView.layoutManager = GridLayoutManager(requireContext(), 2)
        recView.adapter = adapter

        when (dataRepo.getStorage()) {
            dataRepo.SHARED_S -> adapter.submitList(dataRepo.getSharedList())
            dataRepo.PRIVATE_S -> adapter.submitList(dataRepo.getAppList())
        }

        val takePhotoButton: Button = view.findViewById(R.id.takePhotoButton)
        takePhotoButton.setOnClickListener {
            findNavController().navigate(R.id.action_local_to_fragLeft)
        }

        parentFragmentManager.setFragmentResultListener("add", viewLifecycleOwner) {
            _, bundle ->
            if (bundle.getBoolean("add")) {
                findNavController().navigate(R.id.action_local_to_fragLeft)
            }
        }

        parentFragmentManager.setFragmentResultListener("storage", viewLifecycleOwner) {
            _, bundle ->
            val storage = bundle.getInt("storage")
            when (dataRepo.getStorage()) {
                dataRepo.SHARED_S -> adapter.submitList(dataRepo.getSharedList())
                dataRepo.PRIVATE_S -> adapter.submitList(dataRepo.getAppList())
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
//        var img: Int? = null
//        when (vPager.currentItem) {
//            0 -> img = R.drawable.hamster
//            1 -> img = R.drawable.cat
//            2 -> img = R.drawable.dog
//        }
//        val bundle = bundleOf("img" to img)
//
//        parentFragmentManager.setFragmentResult("setupMain", bundle)
//        Log.w("EXTRA", img.toString())
        (activity as MainActivity).clearMenu()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentExtra.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentExtra().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    inner class MyAdapterImage(private val onItemAction: (item: ImageItem, action: Int) -> Unit): ListAdapter<ImageItem, MyAdapterImage.MyViewHolder>(Diffcallback) {
        inner class MyViewHolder(view: View): RecyclerView.ViewHolder(view.rootView) {
            val image: ImageView = view.findViewById(R.id.lrow_image_image)
            val tv1: TextView = view.findViewById(R.id.photoName)
            val tv2: TextView = view.findViewById(R.id.photoPath)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_row_image, parent, false)
            return MyViewHolder(view)
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            val currentItem = getItem(position)

            holder.tv1.text = currentItem.name
            holder.tv2.text = currentItem.path

            try {
                Log.w("EXTRA ORIENTATION", ExifInterface(currentItem.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1).toString())
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                currentItem.curi?.let {
                    holder.image.setImageBitmap(requireContext().contentResolver.loadThumbnail(it, Size(150,200), null))
                }
            } else {
                holder.image.setImageBitmap(getBitmapFromUri(requireContext(), currentItem.curi))
            }

            holder.image.setOnClickListener {
                val position = holder.adapterPosition
                parentFragmentManager.setFragmentResult("vp2", bundleOf("vp2" to position))
                onItemAction(getItem(position), 1)
                true
            }
        }

        fun getBitmapFromUri(mContext: Context, uri: Uri?): Bitmap? {
            var bitmap: Bitmap? = null
            try {
                val image_stream: InputStream
                try {
                    image_stream = uri?.let {
                        mContext.contentResolver.openInputStream(it)
                    }!!
                    bitmap = BitmapFactory.decodeStream(image_stream)
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return bitmap
        }
    }
}

