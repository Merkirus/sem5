package com.example.ex03

import android.net.Uri

class ImageItem {
    var name: String = "Empty"
    var uripath: String = "Empty"
    var path: String = "Empty"
    var curi: Uri? = null

    constructor(name: String, uripath: String, path: String, curi: Uri) {
        this.name = name
        this.uripath = uripath
        this.path = path
        this.curi = curi
    }
}