package com.example.ex03

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.Size
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import androidx.annotation.RequiresApi
import androidx.core.os.bundleOf
import java.io.FileNotFoundException
import java.io.InputStream

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"

/**
 * A simple [Fragment] subclass.
 * Use the [Fragment1.newInstance] factory method to
 * create an instance of this fragment.
 */
class Fragment1 : Fragment() {
    // TODO: Rename and change types of parameters
    private var page: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            page = it.getInt(ARG_PARAM1)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_1, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val img = view.findViewById<ImageView>(R.id.extra_image)
        Log.w("FRAGMENT_IMAGE", page.toString())
        val data = ImageDataRepo.getinstance(requireContext())
        when (data.getStorage()) {
            data.PRIVATE_S -> {
                val item = data.getAppList()?.get(page!!)
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                    img.setImageBitmap(requireContext().contentResolver.loadThumbnail(item?.curi!!, Size(150,200), null))
                } else {
                    img.setImageBitmap(getBitmapFromUri(requireContext(), item?.curi))                }
            }
            data.SHARED_S -> {
                val item = data.getSharedList()?.get(page!!)
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                    img.setImageBitmap(requireContext().contentResolver.loadThumbnail(item?.curi!!, Size(150,200), null))
                } else {
                    img.setImageBitmap(getBitmapFromUri(requireContext(), item?.curi))                }
            }
        }

    }

    fun getBitmapFromUri(mContext: Context, uri: Uri?): Bitmap? {
        var bitmap: Bitmap? = null
        try {
            val image_stream: InputStream
            try {
                image_stream = uri?.let {
                    mContext.contentResolver.openInputStream(it)
                }!!
                bitmap = BitmapFactory.decodeStream(image_stream)
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bitmap
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Fragment1.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(page: Int) =
            Fragment1().apply {
                arguments = Bundle().apply {
                    putInt(ARG_PARAM1, page)
                }
            }
    }
}