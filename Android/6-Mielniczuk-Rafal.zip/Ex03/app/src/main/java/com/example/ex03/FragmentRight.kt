package com.example.ex03

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.ActionMode
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Calendar

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentRight.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentRight : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    lateinit var dataRepo: MyRepository
    lateinit var adapter: MyAdapter2

    private val DiffCallback = object: DiffUtil.ItemCallback<DBItem>() {
        override fun areItemsTheSame(oldItem: DBItem, newItem: DBItem): Boolean {
            return oldItem.id == newItem.id
        }

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: DBItem, newItem: DBItem): Boolean {
            return oldItem == newItem
        }
    }

    val myVModel: MyViewModel by activityViewModels { MyViewModel.Factory }

    val onItemAction: (item: DBItem?, action: Int) -> Unit = {
            item, action ->

        when (action) {
            1 -> {
//                adapter.submitList(myVModel.getAllItems())
                val bundle = bundleOf("name" to item?.text_main, "species" to item?.text_2, "category" to item?.item_type,
                    "cuteness" to item?.item_value, "birth" to item?.item_value2, "power" to item?.power, "id" to item?.id)
                parentFragmentManager.setFragmentResult("detailsItem", bundle)
                findNavController().navigate(R.id.action_local_to_fragDetails)
            }

            2 -> {
                myVModel.deleteItem(item!!)
            }

            3 -> {
                if (myVModel.deleteChecked())
                    Log.w("XDDDDD", "GUT")
                else
                    Log.w("XDDDDD", "BAD")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

        adapter = MyAdapter2(onItemAction)

//        parentFragmentManager.setFragmentResultListener("item_added", this) {
//            requestKey, _ ->
//            adapter.data = dataRepo.getData()!!
//            adapter.notifyDataSetChanged()
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_right, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as MainActivity).setupToolbarFragRight()

        val recView = view.findViewById<RecyclerView>(R.id.recycleView)
        recView.layoutManager = LinearLayoutManager(requireContext())
        recView.adapter = adapter

        myVModel.getAllItems()?.observe(viewLifecycleOwner) { it ->
            adapter.submitList(it)
        }

        val fab: FloatingActionButton = view.findViewById(R.id.right_fab_add)
        fab.setOnClickListener {
            findNavController().navigate(R.id.action_local_to_fragAdd)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        (activity as MainActivity).clearMenu()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentRight.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentRight().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

//    inner class MyAdapter(var data: MutableList<DBItem>): RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
//        inner class MyViewHolder(view: View): RecyclerView.ViewHolder(view.rootView) {
//            val tv1: TextView = view.findViewById(R.id.lrow_tv1)
//            val tv2: TextView = view.findViewById(R.id.lrow_tv2)
//            val img: ImageView = view.findViewById(R.id.lrow_image)
//            val cBox: CheckBox = view.findViewById(R.id.lrow_checkBox)
//        }
//
//        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
//            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_row, parent, false)
//            parentFragmentManager.setFragmentResultListener("delete", viewLifecycleOwner) {
//                    _, bundle ->
//                if (bundle.getBoolean("delete")) {
//                    val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
//                    builder
//                        .setTitle("Do you want to delete checked items?")
//                        .setPositiveButton("Yes") {
//                            dialog, which ->
//                            data.filter { it.item_checked }.forEach {
//                                dataRepo.deleteItem(it)
//                            }
//                            data = dataRepo.getData()!!
//                            notifyDataSetChanged()
//                            Toast.makeText(requireContext(), "You've deleted all chosen items!", Toast.LENGTH_SHORT).show()
//                        }
//                        .setNegativeButton("No") {
//                            dialog, which ->
//                            Toast.makeText(requireContext(), "Canceled", Toast.LENGTH_SHORT).show()
//                        }
//                    builder.create().show()
//                }
//            }
//
//            return MyViewHolder(view)
//        }
//
//
//        override fun getItemCount(): Int {
//            return data.size
//        }
//
//        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
//            holder.tv1.text = data[position].text_main
//            holder.tv2.text = data[position].text_2
//            when (data[position].power) {
//                "weak" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.green))
//                "medium" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.yellow))
//                "strong" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.red))
//            }
//            holder.cBox.isChecked = data[position].item_checked
//            holder.itemView.setOnClickListener {
//                Toast.makeText(requireContext(),
//                    "You clicked: " + (position + 1),
//                    Toast.LENGTH_SHORT).show()
//            }
//            holder.cBox.setOnClickListener { v ->
//                if ((v as CheckBox).isChecked)
//                    data[position].item_checked = true
//                else
//                    data[position].item_checked = false
//                Toast.makeText(requireContext(),
//                    "Selected/Unselected: " + (position + 1),
//                    Toast.LENGTH_SHORT).show()
//            }
//            when (data[position].item_type) {
//                "cat" -> holder.img.setImageResource(R.drawable.cat)
//                "dog" -> holder.img.setImageResource(R.drawable.dog)
//                "hamster" -> holder.img.setImageResource(R.drawable.hamster)
//            }
//            holder.itemView.setOnClickListener {
//                val bundle = bundleOf("id" to data[position].id)
//                parentFragmentManager.setFragmentResult("detailsItem", bundle)
//                findNavController().navigate(R.id.action_local_to_fragDetails)
//            }
//            holder.itemView.setOnLongClickListener {
//                if (dataRepo.deleteItem(data[position])) {
//                    data = dataRepo.getData()!!
//                    notifyDataSetChanged()
//                }
//                true
//            }
//        }
//    }

    inner class MyAdapter2(private val onItemAction: (item: DBItem, action: Int) -> Unit): ListAdapter<DBItem, MyAdapter2.MyViewHolder>(DiffCallback) {
        inner class MyViewHolder(view: View): RecyclerView.ViewHolder(view.rootView) {
            val tv1: TextView = view.findViewById(R.id.lrow_tv1)
            val tv2: TextView = view.findViewById(R.id.lrow_tv2)
            val img: ImageView = view.findViewById(R.id.lrow_image)
            val cBox: CheckBox = view.findViewById(R.id.lrow_checkBox)
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            val currentItem = getItem(position)

            holder.tv1.text = currentItem.text_main
            holder.tv2.text = currentItem.text_2

            when (currentItem.power) {
                "weak" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.green))
                "medium" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.yellow))
                "strong" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.red))
            }

            holder.cBox.isChecked = currentItem.item_checked
            holder.itemView.setOnClickListener {
                Toast.makeText(requireContext(),
                    "You clicked: " + (position + 1),
                    Toast.LENGTH_SHORT).show()
            }
            holder.cBox.setOnClickListener { v ->
                if ((v as CheckBox).isChecked)
                    myVModel.editItem(currentItem.id, "checked", "true")
                else
                    myVModel.editItem(currentItem.id, "checked", "false")
                Toast.makeText(requireContext(),
                    "Selected/Unselected: " + (position + 1),
                    Toast.LENGTH_SHORT).show()
            }
            when (currentItem.item_type) {
                "cat" -> holder.img.setImageResource(R.drawable.cat)
                "dog" -> holder.img.setImageResource(R.drawable.dog)
                "hamster" -> holder.img.setImageResource(R.drawable.hamster)
            }
            holder.itemView.setOnClickListener {
                val position = holder.adapterPosition
                onItemAction(getItem(position), 1)
            }
            holder.itemView.setOnLongClickListener {
                val position = holder.adapterPosition
                onItemAction(getItem(position), 2)
                true
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_row, parent, false)
            parentFragmentManager.setFragmentResultListener("delete", viewLifecycleOwner) {
                    _, bundle ->
                if (bundle.getBoolean("delete")) {
                    val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
                    builder
                        .setTitle("Do you want to delete checked items?")
                        .setPositiveButton("Yes") {
                                dialog, which ->
//                            dataRepo.getData()?.filter { it.item_checked }?.forEach {
//                                dataRepo.deleteItem(it)
//                            }
                            onItemAction(null, 3)
                            Toast.makeText(requireContext(), "You've deleted all chosen items!", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("No") {
                                dialog, which ->
                            Toast.makeText(requireContext(), "Canceled", Toast.LENGTH_SHORT).show()
                        }
                    builder.create().show()
                }
            }

            return MyViewHolder(view)
        }
    }

}

class MyViewModel(context: Context): ViewModel() {

    lateinit var myRepository: MyRepository
//    private var dataList: LiveData<List<DBItem>>

    init {
        myRepository = MyRepository.getinstance(context)
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object: ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(
                modelClass: Class<T>,
                extras: CreationExtras
            ): T {
                val application = checkNotNull(extras[APPLICATION_KEY])
                return MyViewModel(application.applicationContext) as T
            }
        }
    }

    fun getAllItems(): LiveData<List<DBItem>>? = myRepository.getData()

    fun insertItem(item: DBItem?) = myRepository.addItem(item)

    fun deleteItem(item: DBItem?) = myRepository.deleteItem(item)

    fun deleteChecked() = myRepository.deleteChecked()

    fun deleteAll() = myRepository.deleteAll()

    fun editItem(id: Int, attr: String, value: String) = myRepository.editItem(id, attr, value)
}
