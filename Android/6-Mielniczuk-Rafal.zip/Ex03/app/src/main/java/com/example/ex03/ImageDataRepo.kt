package com.example.ex03

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

class ImageDataRepo {
    lateinit var uri: Uri
    val SHARED_S = 1
    val PRIVATE_S = 2
    var photo_storage = SHARED_S

    fun getSharedList(): MutableList<ImageItem>? {
        uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        sharedStoreList?.clear()
        val contentResolver: ContentResolver = ctx.contentResolver
        val cursor = contentResolver.query(uri, null, null, null, null)
        if (cursor == null) {
            // error
        } else if (!cursor.moveToFirst()) {
            // not found
        } else {
            val idColumn = cursor.getColumnIndex(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
            do {
                var thisId = cursor.getLong(idColumn)
                var thisName = cursor.getString(nameColumn)
                val thisContentUri = ContentUris.withAppendedId(uri, thisId)
                val thisUriPath = thisContentUri.toString()
                sharedStoreList?.add(ImageItem(thisName, thisUriPath, thisContentUri.path ?: "Path not found", thisContentUri))
            } while (cursor.moveToNext())
        }

        return sharedStoreList
    }

    fun getAppList(): MutableList<ImageItem>? {
        val dir: File? = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        dir?.listFiles()

        appStoreList?.clear()

        if (dir?.isDirectory == true) {
            var fileList = dir.listFiles()
            if (fileList != null) {
                for (value in fileList) {
                    val fileName = value.name
                    if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") ||
                        fileName.endsWith(".gif") || fileName.endsWith(".png")) {
                        val tmpUri = FileProvider.getUriForFile(ctx, "${BuildConfig.APPLICATION_ID}.provider", value)
                        appStoreList?.add(ImageItem(fileName, value.toURI().path, value.absolutePath, tmpUri))
                    }
                }
            }
        }
        return appStoreList
    }

    fun setStorage(storage: Int): Boolean {
        if (storage != SHARED_S && storage != PRIVATE_S)
            return false
        else
            photo_storage = storage
        return true
    }

    fun getStorage(): Int = photo_storage

    companion object {
        val SHARED_S = 1
        val PRIVATE_S = 2
        private var INSTANCE: ImageDataRepo? = null
        private lateinit var ctx: Context
        var sharedStoreList: MutableList<ImageItem>? = null
        var appStoreList: MutableList<ImageItem>? = null

        fun getinstance(ctx: Context): ImageDataRepo {
            if (INSTANCE == null) {
                INSTANCE = ImageDataRepo()
                sharedStoreList = mutableListOf()
                appStoreList = mutableListOf()
                this.ctx = ctx
            }
            return INSTANCE as ImageDataRepo
        }
    }
}