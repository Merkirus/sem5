package com.example.ex03

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.BoringLayout
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import android.widget.Toolbar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.setFragmentResult
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.ex03.ui.theme.Ex03Theme
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.navigation.NavigationView
import java.text.SimpleDateFormat
import java.util.GregorianCalendar
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() { //, StaticFragment.OnSelectListener {


//    private val TAG_F1 = "Fragment1"
//    private val TAG_F2 = "Fragment2"
//
//    var frag1: Fragment1? = null
//    var frag2: Fragment2? = null
//    var myTrans: FragmentTransaction? = null
    var navBarState = mutableListOf<Int>(0)
    var bottomNavigationView: BottomNavigationView? = null
    var menuMain: Menu? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout = findViewById(R.id.drawerLayout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val navController: NavController = (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).navController

        val appBarConfiguration = AppBarConfiguration(setOf(R.id.center_frag, R.id.left_frag, R.id.right_frag, R.id.extra_frag), drawerLayout)

        toolbar.setupWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE)
        }

//        val navHostFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment
//        val navController = navHostFragment.navController
//        bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavView)
//        bottomNavigationView?.menu?.findItem(R.id.center_frag)?.isChecked = true
//
//        bottomNavigationView?.setOnItemSelectedListener (object: NavigationBarView.OnItemSelectedListener {
//            override fun onNavigationItemSelected(item: MenuItem): Boolean {
//                when (item.itemId) {
//                    R.id.left_frag -> {
//                        navController.navigate(R.id.action_global_to_fragLeft)
//                        navBarState.add(2)
//                    }
//                    R.id.center_frag -> {
//                        navController.navigate(R.id.action_global_to_fragCenter)
//                        navBarState.add(0)
//                    }
//                    R.id.right_frag -> {
//                        navController.navigate(R.id.action_global_to_fragRight)
//                        navBarState.add(1)
//                    }
//                }
////                updateNavBar(bottomNavigationView)
//                return true
//            }
//        })
    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuMain = menu
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_delete -> {
                (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).childFragmentManager.setFragmentResult("delete", bundleOf("delete" to true))
                true
            }
            R.id.menu_add -> {
                (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).childFragmentManager.setFragmentResult("add", bundleOf("add" to true))
                true
            }
            R.id.menu_storage -> {
                var result = 0
                if (ImageDataRepo.getinstance(baseContext).getStorage() == 1) {
                    ImageDataRepo.getinstance(baseContext).setStorage(2)
                    Toast.makeText(baseContext, "Wybrano pamięć prywatną", Toast.LENGTH_SHORT).show()
                    result = 2
                } else {
                    ImageDataRepo.getinstance(baseContext).setStorage(1)
                    Toast.makeText(baseContext, "Wybrano pamięć dzieloną", Toast.LENGTH_SHORT).show()
                    result = 1
                }
                (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).childFragmentManager.setFragmentResult("storage", bundleOf("storage" to result))
                true

            }
            else -> false
        }
    }

    fun setupToolbarFragRight() {
        menuInflater.inflate(R.menu.delete_menu, menuMain)
    }

    fun setupToolbarFragExtra() {
        menuInflater.inflate(R.menu.add_menu, menuMain)
    }

    fun clearMenu() {
        menuMain?.clear()
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            if (!allPermissionsGranted()) {
                Toast.makeText(this, "Permission not granted", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    companion object {
        private const val REQUEST_CODE = 1
        private val REQUIRED_PERMISSIONS = mutableListOf(android.Manifest.permission.CAMERA)
            .apply {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }}
                .toTypedArray()
    }
}

@Entity(tableName = "item_table")
class DBItem {

    @PrimaryKey(autoGenerate = true)
    var id = 0

    @ColumnInfo(name = "name")
    var text_main: String? = null

    @ColumnInfo(name = "species")
    var text_2: String? = null

    @ColumnInfo(name = "rating")
    var item_value = 0

    @ColumnInfo(name = "age")
    var item_value2: String? = null

    @ColumnInfo(name = "power")
    var power: String? = null

    @ColumnInfo(name = "category")
    var item_type: String? = null

    @ColumnInfo(name = "checked")
    var item_checked: Boolean = false

    constructor()
    constructor(num: Int) : this() {
        item_type = CATEGORIES.random()
        text_main = NAMES.random()
        when (item_type) {
            "cat" -> text_2 = CAT_SPECIES.random()
            "dog" -> text_2 = DOG_SPIECIES.random()
            "hamster" -> text_2 = HAMSTER_SPECIES.random()
        }
        when (item_type) {
            "hamster" -> this.power = "weak"
            "cat" -> this.power = "medium"
            "dog" -> this.power = "strong"
        }
        val year = Random.nextInt(1990, 2023)
        val month = Random.nextInt(0,12)
        val day = Random.nextInt(1, 28)
        item_value = Random.nextInt(0,101)
        item_value2 = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(GregorianCalendar(year, month, day).time)
    }
    constructor(name: String?, species: String?, cuteness: Int?, birth: String?, category: String?, power: String?) : this() {
        item_type = category ?: DEFAULT_ITEM_TYPE
        text_main = name ?: DEFAULT_TEXT_MAIN
        text_2 = species ?: DEFAULT_TEXT2
        item_value2 = birth ?: DEFAULT_ITEM_VALUE2
        item_value = cuteness ?: DEFAULT_ITEM_VALUE
        when (item_type) {
            "hamster" -> this.power = "weak"
            "cat" -> this.power = "medium"
            "dog" -> this.power = "strong"
        }
    }

    companion object {
        val DEFAULT_POWER = "medium"
        val DEFAULT_TEXT_MAIN = "Coco"
        val DEFAULT_TEXT2 = "Syrian Hamster"
        val DEFAULT_ITEM_VALUE = 100
        val DEFAULT_ITEM_VALUE2 = "13-04-2012"
        val DEFAULT_ITEM_TYPE = "hamster"
        val CATEGORIES = arrayOf("cat", "dog", "hamster")
        val NAMES = arrayOf("Pimpek", "Coco", "Bobo", "Puszek", "Arnold", "Pipi", "Kajtek", "Fifi")
        val HAMSTER_SPECIES = arrayOf("Chinese Hamster", "Syrian Hamster", "Campbells Hamster")
        val DOG_SPIECIES = arrayOf("Husky", "Dachshund", "Pomeranian")
        val CAT_SPECIES = arrayOf("British cat", "Scottish cat", "Russian Cat", "Persian Cat")
    }
}
