package com.example.ex03

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MyDao {
    @Query("SELECT * FROM item_table ORDER BY id ASC")
    fun getAllData(): MutableList<DBItem>?
    @Query("DELETE FROM item_table")
    fun deleteAll()
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(item: DBItem?): Long
    @Delete
    fun delete(item: DBItem?): Int
    @Query("UPDATE item_table SET name = :columnValue WHERE id = :itemId")
    fun editName(itemId: Int, columnValue: String)
    @Query("UPDATE item_table SET species = :columnValue WHERE id = :itemId")
    fun editSpecies(itemId: Int, columnValue: String)
    @Query("UPDATE item_table SET rating = :columnValue WHERE id = :itemId")
    fun editRating(itemId: Int, columnValue: Int)
    @Query("UPDATE item_table SET age = :columnValue WHERE id = :itemId")
    fun editAge(itemId: Int, columnValue: String?)
    @Query("UPDATE item_table SET category = :columnValue WHERE id = :itemId")
    fun editCategory(itemId: Int, columnValue: String?)
    @Query("UPDATE item_table SET checked = :columnValue WHERE id = :itemId")
    fun editChecked(itemId: Int, columnValue: Boolean)
    @Query("UPDATE item_table SET power = :columnValue WHERE id = :itemId")
    fun editPower(itemId: Int, columnValue: String?)
}