package com.example.ex03

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.os.bundleOf

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentEdit.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentEdit : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private var category: String? = null
    private var position: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        parentFragmentManager.setFragmentResultListener("editItem", viewLifecycleOwner) {
                _, bundle ->
            view.findViewById<TextView>(R.id.edit_name).text = bundle.getString("name")
            view.findViewById<TextView>(R.id.edit_species).text = bundle.getString("species")
            when (bundle.getString("category")) {
                "cat" -> view.findViewById<RadioButton>(R.id.edit_radioCat).isChecked = true
                "dog" -> view.findViewById<RadioButton>(R.id.edit_radioDog).isChecked = true
                "hamster" -> view.findViewById<RadioButton>(R.id.edit_radioHamster).isChecked = true
            }
            view.findViewById<SeekBar>(R.id.edit_cuteness).progress =
                bundle.getString("cuteness")?.toInt() ?: 0
            view.findViewById<TextView>(R.id.edit_birth).text = bundle.getString("birth")

            position = bundle.getString("position")
        }

        val radioGroup: RadioGroup = view.findViewById(R.id.edit_radioGroup)
        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.edit_radioCat -> category = "cat"
                R.id.edit_radioDog -> category = "dog"
                R.id.edit_radioHamster -> category = "hamster"
            }
        }

        val cancelButton: Button = view.findViewById(R.id.edit_cancel_button)
        cancelButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        val saveButton: Button = view.findViewById(R.id.edit_save_button)
        saveButton.setOnClickListener {
//            val name = view.findViewById<TextView>(R.id.edit_name).text.toString()
//            val species = view.findViewById<TextView>(R.id.edit_species).text.toString()
//            val progress = view.findViewById<SeekBar>(R.id.edit_cuteness).progress.toString()
//            val birth = view.findViewById<TextView>(R.id.edit_birth).text.toString()
//            val bundle = bundleOf("name" to name, "species" to species,
//                "category" to category, "cuteness" to progress, "birth" to birth, "position" to position)
//            parentFragmentManager.setFragmentResult("detailsItem", bundle)
//            parentFragmentManager.setFragmentResult("editedItem", bundle)
            parentFragmentManager.popBackStack()
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentEdit.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentEdit().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}