package com.example.ex03

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.core.os.bundleOf

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentAdd.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentAdd : Fragment(), AdapterView.OnItemSelectedListener {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private var category: String? = null
    private var power: String? = null

    private var editionMode: Boolean = false
    private var id: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val radioGroup: RadioGroup = view.findViewById(R.id.add_radioGroup)
        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.add_radioCat -> category = "cat"
                R.id.add_radioDog -> category = "dog"
                R.id.add_radioHamster -> category = "hamster"
            }
        }

        val spinner: Spinner = view.findViewById(R.id.add_power)
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.power,
            android.R.layout.simple_spinner_item
        ).also {
            adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        spinner.onItemSelectedListener = this

        parentFragmentManager.setFragmentResultListener("editItem", viewLifecycleOwner) {
            _, bundle ->
            val item = MyRepository.getinstance(requireContext()).getData()!!.find { it.id == bundle.getInt("id") }
            view.findViewById<TextView>(R.id.add_name).text = item?.text_main
            view.findViewById<TextView>(R.id.add_species).text = item?.text_2
            when (item?.item_type) {
                "cat" -> view.findViewById<RadioButton>(R.id.add_radioCat).isChecked = true
                "dog" -> view.findViewById<RadioButton>(R.id.add_radioDog).isChecked = true
                "hamster" -> view.findViewById<RadioButton>(R.id.add_radioHamster).isChecked = true
            }
            view.findViewById<SeekBar>(R.id.add_cuteness).progress =
                item?.item_value?.toInt() ?: 0
            view.findViewById<TextView>(R.id.add_birth).text = item?.item_value2
            when (item?.power) {
                "weak" -> view.findViewById<Spinner>(R.id.add_power).setSelection(0)
                "medium" -> view.findViewById<Spinner>(R.id.add_power).setSelection(1)
                "strong" -> view.findViewById<Spinner>(R.id.add_power).setSelection(2)
            }
            editionMode = true
            id = bundle.getInt("id")
        }

        val cancelButton: Button = view.findViewById(R.id.add_cancel_button)
        cancelButton.setOnClickListener {
            editionMode = false
            parentFragmentManager.popBackStack()
        }

        val saveButton: Button = view.findViewById(R.id.add_save_button)
        saveButton.setOnClickListener {
            val name = view.findViewById<EditText>(R.id.add_name).text.toString()
            val species = view.findViewById<EditText>(R.id.add_species).text.toString()
            val cuteness = view.findViewById<SeekBar>(R.id.add_cuteness).progress.toString()
            val birth = view.findViewById<EditText>(R.id.add_birth).text.toString()
            val power = power
            val category = category
            if (editionMode) {
                MyRepository.getinstance(requireContext()).editItem(id!!, "name", name)
                MyRepository.getinstance(requireContext()).editItem(id!!, "species", species)
                MyRepository.getinstance(requireContext()).editItem(id!!, "rating", cuteness)
                MyRepository.getinstance(requireContext()).editItem(id!!, "category", category!!)
                MyRepository.getinstance(requireContext()).editItem(id!!, "age", birth)
                MyRepository.getinstance(requireContext()).editItem(id!!, "power", power!!)
                parentFragmentManager.setFragmentResult("detailsItem", bundleOf("id" to id))
                parentFragmentManager.setFragmentResult("item_added", Bundle.EMPTY)
            } else {
                val item = DBItem(name, species, cuteness.toInt(), birth, category, power)
                if (MyRepository.getinstance(requireContext()).addItem(item))
                    parentFragmentManager.setFragmentResult("item_added", Bundle.EMPTY)
            }
            editionMode = false
            parentFragmentManager.popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.w("ADD", parentFragment.toString())
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        if (parent != null) {
            power = parent.getItemAtPosition(position).toString()
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentAdd.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentAdd().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}