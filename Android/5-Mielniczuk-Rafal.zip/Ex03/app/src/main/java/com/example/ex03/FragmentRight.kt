package com.example.ex03

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.ActionMode
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Calendar

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentRight.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentRight : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    lateinit var dataRepo: MyRepository
    lateinit var adapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

        dataRepo = MyRepository.getinstance(requireContext())
        adapter = MyAdapter(dataRepo.getData()!!)

        parentFragmentManager.setFragmentResultListener("item_added", this) {
            requestKey, _ ->
            adapter.data = dataRepo.getData()!!
            adapter.notifyDataSetChanged()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_right, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as MainActivity).setupToolbarFragRight()

        val recView = view.findViewById<RecyclerView>(R.id.recycleView)
        recView.layoutManager = LinearLayoutManager(requireContext())
        recView.adapter = adapter

        val fab: FloatingActionButton = view.findViewById(R.id.right_fab_add)
        fab.setOnClickListener {
            findNavController().navigate(R.id.action_local_to_fragAdd)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        (activity as MainActivity).clearMenu()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentRight.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentRight().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    inner class MyAdapter(var data: MutableList<DBItem>): RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
        inner class MyViewHolder(view: View): RecyclerView.ViewHolder(view.rootView) {
            val tv1: TextView = view.findViewById(R.id.lrow_tv1)
            val tv2: TextView = view.findViewById(R.id.lrow_tv2)
            val img: ImageView = view.findViewById(R.id.lrow_image)
            val cBox: CheckBox = view.findViewById(R.id.lrow_checkBox)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.list_row, parent, false)
            parentFragmentManager.setFragmentResultListener("delete", viewLifecycleOwner) {
                    _, bundle ->
                if (bundle.getBoolean("delete")) {
                    val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
                    builder
                        .setTitle("Do you want to delete checked items?")
                        .setPositiveButton("Yes") {
                            dialog, which ->
                            data.filter { it.item_checked }.forEach {
                                dataRepo.deleteItem(it)
                            }
                            data = dataRepo.getData()!!
                            notifyDataSetChanged()
                            Toast.makeText(requireContext(), "You've deleted all chosen items!", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("No") {
                            dialog, which ->
                            Toast.makeText(requireContext(), "Canceled", Toast.LENGTH_SHORT).show()
                        }
                    builder.create().show()
                }
            }

            return MyViewHolder(view)
        }

        override fun getItemCount(): Int {
            return data.size
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            holder.tv1.text = data[position].text_main
            holder.tv2.text = data[position].text_2
            when (data[position].power) {
                "weak" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.green))
                "medium" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.yellow))
                "strong" -> holder.itemView.setBackgroundColor(resources.getColor(R.color.red))
            }
            holder.cBox.isChecked = data[position].item_checked
            holder.itemView.setOnClickListener {
                Toast.makeText(requireContext(),
                    "You clicked: " + (position + 1),
                    Toast.LENGTH_SHORT).show()
            }
            holder.cBox.setOnClickListener { v ->
                if ((v as CheckBox).isChecked)
                    data[position].item_checked = true
                else
                    data[position].item_checked = false
                Toast.makeText(requireContext(),
                    "Selected/Unselected: " + (position + 1),
                    Toast.LENGTH_SHORT).show()
            }
            when (data[position].item_type) {
                "cat" -> holder.img.setImageResource(R.drawable.cat)
                "dog" -> holder.img.setImageResource(R.drawable.dog)
                "hamster" -> holder.img.setImageResource(R.drawable.hamster)
            }
            holder.itemView.setOnClickListener {
                val bundle = bundleOf("id" to data[position].id)
                parentFragmentManager.setFragmentResult("detailsItem", bundle)
                findNavController().navigate(R.id.action_local_to_fragDetails)
            }
            holder.itemView.setOnLongClickListener {
                if (dataRepo.deleteItem(data[position])) {
                    data = dataRepo.getData()!!
                    notifyDataSetChanged()
                }
                true
            }
        }
    }
}
